# Cpoy-Text-Extension

### 文字复制插件 firefox版
